package com.example.lenovo.experiment;

import java.io.Serializable;

/**
 * Created by lenovo on 2018/1/5.
 */

public class SortModel implements Serializable {

    private String name;   //显示的数据
    private String sortLetters;  //显示数据拼音的首字母
    private String numbers; //显示存储的号码
    private String notes; //显示备注

    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getSortLetters() {
        return sortLetters;
    }
    public void setSortLetters(String sortLetters) {
        this.sortLetters = sortLetters;
    }

    public String getNumbers() {
        return numbers;
    }

    public void setNumbers(String numbers) {
        this.numbers = numbers;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }
}
