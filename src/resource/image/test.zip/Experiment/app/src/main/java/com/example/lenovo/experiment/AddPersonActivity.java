package com.example.lenovo.experiment;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;

/**
 * Created by lenovo on 2018/1/7.
 */

public class AddPersonActivity extends Activity {

    private EditText personName;

    private EditText personPhone;

    private EditText personNote;

    private ImageButton addPerson;

    private ImageButton finish;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_person);
        personName = findViewById(R.id.personName);
        personPhone = findViewById(R.id.personPhone);
        personNote = findViewById(R.id.personNote);
        addPerson = findViewById(R.id.add_person);
        finish = findViewById(R.id.finish);
        finish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AddPersonActivity.this.finish();
            }
        });
        addPerson.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = getIntent();
                String name = personName.getText().toString();
                String phone = personPhone.getText().toString();
                String note = personNote.getText().toString();
                SortModel sortModel = new SortModel();
                sortModel.setName(name);
                sortModel.setNumbers(phone);
                sortModel.setNotes(note);
                intent.putExtra("person",sortModel);
                AddPersonActivity.this.setResult(0,intent);
                AddPersonActivity.this.finish();
            }
        });
    }

}
