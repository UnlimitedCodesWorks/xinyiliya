package com.example.lenovo.experiment;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;

/**
 * Created by lenovo on 2018/1/7.
 */

public class EditPersonActivity extends Activity {

    private EditText personName;

    private EditText personPhone;

    private EditText personNote;

    private Button deleteButton;

    private ImageButton addPerson;

    private ImageButton finish;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.edit_person_layout);
        personName = findViewById(R.id.edit_personName);
        personPhone = findViewById(R.id.edit_personPhone);
        personNote = findViewById(R.id.edit_personNote);
        addPerson = findViewById(R.id.edit_person);
        finish = findViewById(R.id.edit_finish);
        deleteButton = findViewById(R.id.delete);
        SortModel sortModel = (SortModel) getIntent().getExtras().getSerializable("person");
        personName.setText(sortModel.getName());
        personPhone.setText(sortModel.getNumbers());
        personNote.setText(sortModel.getNotes());
        finish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = getIntent();
                String name = personName.getText().toString();
                String phone = personPhone.getText().toString();
                String note = personNote.getText().toString();
                SortModel sortModel = new SortModel();
                sortModel.setName(name);
                sortModel.setNumbers(phone);
                sortModel.setNotes(note);
                intent.putExtra("edit_person",sortModel);
                EditPersonActivity.this.setResult(1,intent);
                EditPersonActivity.this.finish();
            }
        });
        addPerson.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = getIntent();
                String name = personName.getText().toString();
                String phone = personPhone.getText().toString();
                String note = personNote.getText().toString();
                SortModel sortModel = new SortModel();
                sortModel.setName(name);
                sortModel.setNumbers(phone);
                sortModel.setNotes(note);
                intent.putExtra("edit_person",sortModel);
                EditPersonActivity.this.setResult(1,intent);
                EditPersonActivity.this.finish();
            }
        });
        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = getIntent();
                EditPersonActivity.this.setResult(2,intent);
                EditPersonActivity.this.finish();
            }
        });
    }
}
